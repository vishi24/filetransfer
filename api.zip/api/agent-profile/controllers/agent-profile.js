'use strict';

/**
 * agent-profile controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::agent-profile.agent-profile');
