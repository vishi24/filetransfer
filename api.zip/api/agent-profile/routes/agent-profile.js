'use strict';

/**
 * agent-profile router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::agent-profile.agent-profile');
