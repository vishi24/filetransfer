'use strict';

/**
 * appointment-status controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::appointment-status.appointment-status');
