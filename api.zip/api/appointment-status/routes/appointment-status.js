'use strict';

/**
 * appointment-status router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::appointment-status.appointment-status');
