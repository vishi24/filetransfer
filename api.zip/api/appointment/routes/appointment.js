'use strict';

/**
 * appointment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::appointment.appointment');
