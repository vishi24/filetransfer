'use strict';

/**
 * attribute controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::attribute.attribute');
