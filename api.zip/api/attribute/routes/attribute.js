'use strict';

/**
 * attribute router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::attribute.attribute');
