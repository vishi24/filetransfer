'use strict';

/**
 * cancel-term controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::cancel-term.cancel-term');
