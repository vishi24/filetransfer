'use strict';

/**
 * cat-attr-tag-relation controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::cat-attr-tag-relation.cat-attr-tag-relation');
