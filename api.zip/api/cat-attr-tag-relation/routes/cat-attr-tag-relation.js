'use strict';

/**
 * cat-attr-tag-relation router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::cat-attr-tag-relation.cat-attr-tag-relation');
