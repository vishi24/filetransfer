'use strict';

/**
 * cat-attr-tag-relation service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::cat-attr-tag-relation.cat-attr-tag-relation');
