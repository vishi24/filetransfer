'use strict';

/**
 * fulfilment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::fulfilment.fulfilment');
