'use strict';

/**
 * fulfilment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::fulfilment.fulfilment');
