'use strict';

/**
 * input-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::input-detail.input-detail');
