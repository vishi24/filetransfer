'use strict';

/**
 * input controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::input.input');
