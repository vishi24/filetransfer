'use strict';

/**
 * item-fulfillment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::item-fulfillment.item-fulfillment');
