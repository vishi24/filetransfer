'use strict';

/**
 * item-fulfillment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::item-fulfillment.item-fulfillment');
