'use strict';

/**
 * item-fulfillment service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::item-fulfillment.item-fulfillment');
