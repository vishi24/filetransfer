'use strict';

/**
 * item-meta-taxanomy controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::item-meta-taxanomy.item-meta-taxanomy');
