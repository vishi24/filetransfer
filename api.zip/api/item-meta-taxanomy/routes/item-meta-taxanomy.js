'use strict';

/**
 * item-meta-taxanomy router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::item-meta-taxanomy.item-meta-taxanomy');
