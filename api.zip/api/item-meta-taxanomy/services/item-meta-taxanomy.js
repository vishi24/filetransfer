'use strict';

/**
 * item-meta-taxanomy service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::item-meta-taxanomy.item-meta-taxanomy');
