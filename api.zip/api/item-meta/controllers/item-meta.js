'use strict';

/**
 * item-meta controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::item-meta.item-meta');
