'use strict';

/**
 * item-meta router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::item-meta.item-meta');
