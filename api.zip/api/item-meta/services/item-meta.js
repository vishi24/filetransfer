'use strict';

/**
 * item-meta service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::item-meta.item-meta');
