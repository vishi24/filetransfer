'use strict';

/**
 * item-shipping-location controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::item-shipping-location.item-shipping-location');
