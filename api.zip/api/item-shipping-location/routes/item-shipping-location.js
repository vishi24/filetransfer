'use strict';

/**
 * item-shipping-location router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::item-shipping-location.item-shipping-location');
