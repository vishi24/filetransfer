'use strict';

/**
 * item-shipping-location service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::item-shipping-location.item-shipping-location');
