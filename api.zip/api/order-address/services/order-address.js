'use strict';

/**
 * order-address service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-address.order-address');
