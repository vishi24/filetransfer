'use strict';

/**
 * order-fulfillment-location controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-fulfillment-location.order-fulfillment-location');
