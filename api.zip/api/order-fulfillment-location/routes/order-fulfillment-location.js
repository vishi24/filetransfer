'use strict';

/**
 * order-fulfillment-location router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-fulfillment-location.order-fulfillment-location');
