'use strict';

/**
 * order-fulfillment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-fulfillment.order-fulfillment');
