'use strict';

/**
 * order-fulfillment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-fulfillment.order-fulfillment');
