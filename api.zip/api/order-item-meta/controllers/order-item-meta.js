'use strict';

/**
 * order-item-meta controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-item-meta.order-item-meta');
