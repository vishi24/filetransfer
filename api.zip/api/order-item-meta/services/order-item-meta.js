'use strict';

/**
 * order-item-meta service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-item-meta.order-item-meta');
