'use strict';

/**
 * order-item service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-item.order-item');
