'use strict';

/**
 * order-meta controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-meta.order-meta');
