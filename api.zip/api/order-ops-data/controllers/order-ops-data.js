'use strict';

/**
 * order-ops-data controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-ops-data.order-ops-data');
