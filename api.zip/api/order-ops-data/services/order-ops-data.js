'use strict';

/**
 * order-ops-data service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-ops-data.order-ops-data');
