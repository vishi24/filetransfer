'use strict';

/**
 * order-product-lookup controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-product-lookup.order-product-lookup');
