'use strict';

/**
 * order-product-lookup service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-product-lookup.order-product-lookup');
