'use strict';

/**
 * order-shipping-detail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-shipping-detail.order-shipping-detail');
