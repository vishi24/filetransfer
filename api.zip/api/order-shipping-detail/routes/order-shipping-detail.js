'use strict';

/**
 * order-shipping-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-shipping-detail.order-shipping-detail');
