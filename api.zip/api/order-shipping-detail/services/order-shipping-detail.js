'use strict';

/**
 * order-shipping-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-shipping-detail.order-shipping-detail');
