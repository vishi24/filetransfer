'use strict';

/**
 * order-tracking controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-tracking.order-tracking');
