'use strict';

/**
 * payment-method router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::payment-method.payment-method');
