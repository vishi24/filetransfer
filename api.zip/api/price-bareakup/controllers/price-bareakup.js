'use strict';

/**
 * price-bareakup controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::price-bareakup.price-bareakup');
