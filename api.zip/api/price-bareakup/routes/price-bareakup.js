'use strict';

/**
 * price-bareakup router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::price-bareakup.price-bareakup');
