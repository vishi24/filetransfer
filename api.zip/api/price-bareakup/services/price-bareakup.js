'use strict';

/**
 * price-bareakup service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::price-bareakup.price-bareakup');
