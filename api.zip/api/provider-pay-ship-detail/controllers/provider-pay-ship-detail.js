'use strict';

/**
 * provider-pay-ship-detail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::provider-pay-ship-detail.provider-pay-ship-detail');
