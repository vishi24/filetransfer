'use strict';

/**
 * provider-pay-ship-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::provider-pay-ship-detail.provider-pay-ship-detail');
