'use strict';

/**
 * provider-pay-ship-detail service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::provider-pay-ship-detail.provider-pay-ship-detail');
