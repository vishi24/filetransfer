'use strict';

/**
 * provider-shipping-location controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::provider-shipping-location.provider-shipping-location');
