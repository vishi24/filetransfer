'use strict';

/**
 * provider-shipping-location router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::provider-shipping-location.provider-shipping-location');
