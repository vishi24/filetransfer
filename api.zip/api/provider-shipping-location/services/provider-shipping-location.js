'use strict';

/**
 * provider-shipping-location service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::provider-shipping-location.provider-shipping-location');
