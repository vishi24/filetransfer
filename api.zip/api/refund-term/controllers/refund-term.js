'use strict';

/**
 * refund-term controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::refund-term.refund-term');
