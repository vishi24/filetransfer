'use strict';

/**
 * refund-term router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::refund-term.refund-term');
