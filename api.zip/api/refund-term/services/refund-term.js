'use strict';

/**
 * refund-term service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::refund-term.refund-term');
