'use strict';

/**
 * return-cancellation controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::return-cancellation.return-cancellation');
