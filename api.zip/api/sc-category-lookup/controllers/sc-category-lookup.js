'use strict';

/**
 * sc-category-lookup controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-category-lookup.sc-category-lookup');
