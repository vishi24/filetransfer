'use strict';

/**
 * sc-category-lookup router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sc-category-lookup.sc-category-lookup');
