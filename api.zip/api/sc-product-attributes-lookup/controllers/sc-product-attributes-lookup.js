'use strict';

/**
 * sc-product-attributes-lookup controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-product-attributes-lookup.sc-product-attributes-lookup');
