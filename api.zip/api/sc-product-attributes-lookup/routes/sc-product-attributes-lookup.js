'use strict';

/**
 * sc-product-attributes-lookup router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sc-product-attributes-lookup.sc-product-attributes-lookup');
