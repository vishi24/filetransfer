'use strict';

/**
 * sc-product-attributes-lookup service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sc-product-attributes-lookup.sc-product-attributes-lookup');
