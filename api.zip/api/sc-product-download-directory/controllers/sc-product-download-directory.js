'use strict';

/**
 * sc-product-download-directory controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-product-download-directory.sc-product-download-directory');
