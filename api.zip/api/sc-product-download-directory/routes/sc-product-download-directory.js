'use strict';

/**
 * sc-product-download-directory router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sc-product-download-directory.sc-product-download-directory');
