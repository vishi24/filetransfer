'use strict';

/**
 * sc-product-download-directory service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sc-product-download-directory.sc-product-download-directory');
