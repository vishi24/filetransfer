'use strict';

/**
 * sc-product controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-product.sc-product');
