'use strict';

/**
 * sc-product service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sc-product.sc-product');
