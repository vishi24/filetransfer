'use strict';

/**
 * sc-retail-product-cancel controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-retail-product-cancel.sc-retail-product-cancel');
