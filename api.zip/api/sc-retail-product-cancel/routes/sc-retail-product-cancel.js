'use strict';

/**
 * sc-retail-product-cancel router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sc-retail-product-cancel.sc-retail-product-cancel');
