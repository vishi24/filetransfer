'use strict';

/**
 * sc-retail-product-cancel service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sc-retail-product-cancel.sc-retail-product-cancel');
