'use strict';

/**
 * sc-retail-product-refund controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sc-retail-product-refund.sc-retail-product-refund');
