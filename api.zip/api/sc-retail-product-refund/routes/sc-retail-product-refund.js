'use strict';

/**
 * sc-retail-product-refund router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sc-retail-product-refund.sc-retail-product-refund');
