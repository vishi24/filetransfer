'use strict';

/**
 * sc-retail-product-refund service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sc-retail-product-refund.sc-retail-product-refund');
