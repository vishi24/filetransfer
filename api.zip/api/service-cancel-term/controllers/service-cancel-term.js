'use strict';

/**
 * service-cancel-term controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::service-cancel-term.service-cancel-term');
