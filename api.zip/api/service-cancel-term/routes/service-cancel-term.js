'use strict';

/**
 * service-cancel-term router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::service-cancel-term.service-cancel-term');
