'use strict';

/**
 * service-cancel-term service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::service-cancel-term.service-cancel-term');
