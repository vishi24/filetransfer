'use strict';

/**
 * service-refund-term controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::service-refund-term.service-refund-term');
