'use strict';

/**
 * service-refund-term router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::service-refund-term.service-refund-term');
