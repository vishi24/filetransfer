'use strict';

/**
 * service-refund-term service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::service-refund-term.service-refund-term');
