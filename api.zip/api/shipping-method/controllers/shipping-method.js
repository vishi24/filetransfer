'use strict';

/**
 * shipping-method controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::shipping-method.shipping-method');
