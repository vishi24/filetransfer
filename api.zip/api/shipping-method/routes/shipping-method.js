'use strict';

/**
 * shipping-method router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::shipping-method.shipping-method');
