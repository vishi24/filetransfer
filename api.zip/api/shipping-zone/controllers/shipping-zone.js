'use strict';

/**
 * shipping-zone controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::shipping-zone.shipping-zone');
