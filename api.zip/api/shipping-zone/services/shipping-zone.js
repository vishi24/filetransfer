'use strict';

/**
 * shipping-zone service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::shipping-zone.shipping-zone');
