'use strict';

/**
 * tag-group controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::tag-group.tag-group');
