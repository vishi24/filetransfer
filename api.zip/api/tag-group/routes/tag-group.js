'use strict';

/**
 * tag-group router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::tag-group.tag-group');
