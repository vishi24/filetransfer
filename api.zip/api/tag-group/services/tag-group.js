'use strict';

/**
 * tag-group service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::tag-group.tag-group');
